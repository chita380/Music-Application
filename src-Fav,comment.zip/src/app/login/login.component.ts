import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { isEmpty } from 'rxjs/operators';
import { User } from '../model/user';
import { RegistrationService } from '../service/registration.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user:User=new User();
  msg:string;
  errorMsg:string;
  userData: any;
 myData:any;
  // view :boolean=true;
  
  constructor(private regService:RegistrationService,private router:Router) { }
  ngOnInit(): void {
    // localStorage.setItem("lastname", "Smith");
    
  }
 
  loginUser(){
    console.log("Add new Employee.");
    console.log(this.user);
    this.regService.loginUser(this.user).subscribe(
      (data)=>{
        // if (data) {
        //   this.userData = data; // Setting up user data in userData var
        //   localStorage.setItem('user', JSON.stringify(this.userData));
        //  this.myData=JSON.parse(localStorage.getItem('data'));
        //   console.log(this.myData);
        
        
        // } 
        // else {
        //   localStorage.setItem('data', null);
        //   JSON.parse(localStorage.getItem('data'));
        // }
        // localStorage.setItem(JSON.stringify(data.password),JSON.stringify(data.emailId));
      console.log("Data",data);
      this.msg=data;
      this.errorMsg=undefined;
     
      this.router.navigate(['dashboard'])
      
          },
      (error)=>{
        this.errorMsg=error.error;
      console.log(this.errorMsg);
      this.msg=undefined;
            }
      );
      // this.view=false;
  }
 
  gotoregistration(){
    this.router.navigate(['registration'])
  }
 
  
}
