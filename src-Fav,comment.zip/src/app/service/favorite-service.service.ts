import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Favo } from '../model/Favo';

@Injectable({
  providedIn: 'root'
})
export class FavoriteServiceService {

  constructor(private http:HttpClient) { }

  getFav(emailId:string):Observable<Favo[]>{
    return this.http.get<Favo[]>("http://localhost:8086/fav/"+emailId);
  }

  delfav(fav:Favo){
    return this.http.put<any>("http://localhost:8086/fav/delfav",fav);
  }
  updfav(fav:Favo){
    return this.http.put<any>("http://localhost:8086/fav/updfav",fav);
  }
}

