import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SearchComponent } from './search/search.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { FavmusiclistComponent } from './favmusiclist/favmusiclist.component';
import { ViewplaylistComponent } from './viewplaylist/viewplaylist.component';
import { AddplaylistComponent } from './addplaylist/addplaylist.component';

const routes: Routes = [
  { path: 'search', component: SearchComponent },
  { path: 'login', component: LoginComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'dashboard', component: DashBoardComponent },
  { path: 'edit', component: EditProfileComponent },
  { path: 'fav', component: FavmusiclistComponent },
  { path: 'dashboard/viewpl', component: ViewplaylistComponent },
  { path: 'dashboard/addpl', component: AddplaylistComponent },

];

@NgModule({
  imports: [CommonModule, RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
