import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../model/user';
import { RegistrationService } from '../service/registration.service';
import{LoginComponent} from '../login/login.component';
@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {

  user:User=new User();
  editusers:string;
  msg: any;
  errorMsg: any;
  //isUpdate: boolean;
  // isUpdate=false;

  constructor(public log:LoginComponent,private router:Router,public reg:RegistrationService) {  
    //  console.log("subData",JSON.stringify(log.userData));
    //  this.editusers=JSON.stringify(log.userData);
    //  console.log("User data",this.editusers);
    
  }
  ngOnInit(): void {
    this.user=this.log.userData;
    console.log(this.user);
  }

 
  // public viewUpdateUser(user:User){  // emp object of row where update button clicked(old data)
  //   console.log("Emp :"+ JSON.stringify(user));
  //   this.isUpdate=true;
  //   this.user=user; //older value rep in form due to this line
  // }

  submitchanges(){
    // this.reg.editUser(this.user).subscribe(
    //   (data)=>{
    //   console.log("Data",data);
    //   this.msg=data;
    //   this.errorMsg=undefined;
     
      
    //       },
    //   (error)=>{
    //     this.errorMsg=error.error;
    //   console.log(this.errorMsg);
    //   this.msg=undefined;
    //         }
    //   );
     
    //  this.isUpdate=false;
      
  }

}
