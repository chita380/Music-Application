import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FavmusiclistComponent } from './favmusiclist.component';

describe('FavmusiclistComponent', () => {
  let component: FavmusiclistComponent;
  let fixture: ComponentFixture<FavmusiclistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FavmusiclistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FavmusiclistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
