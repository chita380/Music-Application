import { Component, OnInit } from '@angular/core';
import {SearchServiceService} from '../service/search-service.service'
import{FavoriteserviceService} from '../service/favoriteservice.service';
import {Album, Artist, Data, Image, Playlist, Search, SearchResults, Track,AlbumLinks} from '../model/artist'
import { RegistrationService, } from '../service/registration.service';
import { Favo } from '../model/Favo';
@Component({
  selector: 'app-favmusiclist',
  templateUrl: './favmusiclist.component.html',
  styleUrls: ['./favmusiclist.component.css']
})
export class FavmusiclistComponent implements OnInit {
  commentUpdated:string;
  fav:Favo[];
  albums : Album[] = [];
  artists : Artist[] = [];
  tracks : Track[] = [];
  playlists :Playlist[] = [];
  searching :Search = new Search();
  datasearch :Data = new Data();
  imageAlbum :Image[] = [];
  searchtext :string="";
  
  links :AlbumLinks =new AlbumLinks();

  currentUser:any;
  imageurl:string[]=[];
  constructor(private search:SearchServiceService,private favser:FavoriteserviceService,public regser:RegistrationService) { this.currentUser=JSON.parse(localStorage.getItem('currentUser'));
  console.log(this.currentUser.emailId)}

  ngOnInit(): void {
    this.getFavs()
  }
  getFavs(){
    this.favser.getFav(this.currentUser.emailId).subscribe(
      fav=>{this.fav=fav ;
        this.fav.forEach(element => {
        
       this.getimglink(element.songImage);
      });  
      }   
    );

  }
 
   
 getimglink(str:string){
   this.search.getimageobj(str).subscribe(Response => {
     console.log(Response)
     this.imageurl.push(Response.images[0].url);
     console.log(this.imageurl);
   }

   );
 }
 counter:number=0;
 imageelements():string{
   var url:string="";
   if(this.imageurl.length==this.counter){
   url= this.imageurl[this.counter];
   this.counter=0;
   
   }
   else
   {
     url=this.imageurl[this.counter++];
   }
   return url;
 }

 delfav(fav:Favo){
  this.favser.delfav(fav).subscribe(
   ele=>fav.deltemp=ele
    );    

}
updfav(fav:Favo){
   //fav.comment=this.commentUpdated
  console.log(fav.comment)

  this.favser.updfav(fav).subscribe(
    
  )
}

}
