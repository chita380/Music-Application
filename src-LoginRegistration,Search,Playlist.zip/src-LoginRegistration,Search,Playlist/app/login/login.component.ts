import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../model/user';
import { RegistrationService } from '../service/registration.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: User = new User();
  msg: string;
  errorMsg: string;
  userData: any;
  myData: any;


  constructor(private regService: RegistrationService, private router: Router) { }

  ngOnInit(): void {
    // localStorage.setItem("lastname", "Smith");
  }

  loginUser() {
    console.log("Add new User.");
    console.log(this.user);
    this.regService.loginUser(this.user).subscribe(
      (data) => {
        this.userData = data; // Setting up user data in userData var
        localStorage.setItem('user', JSON.stringify(this.userData));//obj to jsonstring
        this.myData = JSON.parse(localStorage.getItem('user'));//MY DATA IS OBJ  , jsonstring to obj
        console.log(this.myData);
        console.log("Data", data);
        this.msg = data;
        this.errorMsg = undefined;

        this.router.navigate(['dashboard'])
      },

      (error) => {
        this.errorMsg = error.error;
        console.log(this.errorMsg);
        this.msg = undefined;
      }
    );
  }

  gotoregistration() {
    this.router.navigate(['registration'])
  }
}
