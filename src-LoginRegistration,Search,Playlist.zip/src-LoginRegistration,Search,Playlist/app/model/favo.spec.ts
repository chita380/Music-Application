import { Favo } from './favo';

describe('Favo', () => {
  it('should create an instance', () => {
    expect(new Favo()).toBeTruthy();
  });
});
