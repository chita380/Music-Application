export class Favo {
    
        songId:string;
        emailId:string;
        comment:string;
        songImage:string;
        songName:string;
        releasedDate:string;
        songLabel:string;
        songAlbum:string;
        songTracks:string;
        songPosts:string;
        songArtists:string;
        songGenres:string;
        deltemp:boolean=false
        temp:boolean=false;
        updtemp:boolean=false;
        edittemp:boolean=false;
    }


