import { Playlist } from './playlist';

describe('Playlist', () => {
  it('should create an instance', () => {
    expect(new Playlist()).toBeTruthy();
  });
});
