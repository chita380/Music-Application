export class Playlist {
    id: string;
    name: string;
    type: string;
    description: string;
}
