import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../model/user';
import { RegistrationService } from '../service/registration.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  user: User = new User();
  msg: string;
  errorMsg: string;
  view: boolean = true;

  constructor(private regService: RegistrationService, private router: Router) { }


  ngOnInit(): void {
  }
  regUser() {
    console.log("Add new user");
    console.log(this.user);
    this.regService.regUser(this.user).subscribe(
      (data) => {
        console.log("Data", data);
        this.msg = data;
        this.errorMsg = undefined;
        this.router.navigate(['login'])
      },

      (error) => {
        this.errorMsg = error.error;
        console.log(this.errorMsg);
        this.msg = undefined;
      }
    );
    this.view = false;
  }

  gotologin() {
    this.router.navigate(['login'])
  }

}
